Second version
