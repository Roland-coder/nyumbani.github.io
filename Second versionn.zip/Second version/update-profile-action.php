<?php 
include 'server.php';
// session_start();
if (isset($_GET['update_profile']))
{
    // $user = $_GET['user'];
	// $fullname = $_POST['fullname'];
	// $age = $_POST['age'];
	// $gender = $_POST['gender'];
	$email = $_POST['email'];
	$update_profile = $mysqli->query("UPDATE users SET  email = '$email',
					  WHERE username = '$user'");
	
	header("Location: profile.php?user=$user");
 	// header("Location: profile.php?user=$user");
}
// $update_profile = $mysqli->query("UPDATE users SET full_name = '$fullname',
// gender = '$gender', age = $age, address = '$address'
// WHERE username = '$user'");	    
// 	if ($update_profile) {
// 			   
// 		header("Location: profile.php?user=$user");
// 		    
// 	} else {
// 			  echo $mysqli->error;
// 		    }
// }	

// if($update_profile){
		
// 	header("Location: profile.php?user=$user");
// 	} 
?>