
<?php
    $connection = mysqli_connect("localhost", "root", ""); // Establishing Connection with Server
    $db = mysqli_select_db( $connection, "contact"); // Selecting Database from Server
    if(isset($_POST['contactus'])){ // Fetching variables of the form which travels in URL
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    //Insert Query of SQL
    $query = "insert into responses(fname, lname, email, subject, message) values ('$fname', '$lname', '$email', '$subject', '$message')";
    if($connection->Query($query) === TRUE){
        echo "<br/><br/><span>Data Inserted successfully...!!</span>";
        $_SESSION['fname'] = $fname;
  	    $_SESSION['success'] = "Data Inserted successfully...!!";
    // header('location: index.php');
        header('location: main.php');
        echo "<br/><br/><span>Data Inserted successfully...!!</span>";
    }

    else{
       echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
    }
    }
    mysqli_close($connection); // Closing Connection with Server
?>
