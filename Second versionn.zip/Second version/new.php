
 <!DOCTYPE HTML>   
 <html>
     <head>
        <title>Nyumbani website</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,900|Playfair+Display:400,700,900 " rel="stylesheet">
        <link rel="stylesheet" href="fonts/icomoon/style.css">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/owl.carousel.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">
        <link rel="stylesheet" href="css/owl.theme.default.min.css">

        <link rel="stylesheet" href="css/jquery.fancybox.min.css">

        <link rel="stylesheet" href="css/bootstrap-datepicker.css">

        <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

        <link rel="stylesheet" href="css/aos.css">

        <link rel="stylesheet" href="css/style.css">
        

    </head>
    <body>
        <section class="site-section bg-light bg-image" id="contact-section">
            <div class="container">
                <div class="row mb-5">
                <div class="col-12 text-center">
                    <!-- <h3 class="section-sub-title">Get</h3> -->
                    <h2 class="section-title mb-3">Contct Us</h2>
                </div>
                </div>
                <div class="row">
                <div class="col-md-7 mb-5">

                    

                    <form action="insert.php" method="post" class="p-5 bg-white">
                    
                    <h2 class="h4 text-black mb-5">Contact Form</h2> 
                    
                    
                    <!-- // $fname = "";
                    // $lname = "";
                    // $email = "";
                    // $subject = "";
                    // $message = "";
                    // $errors = array();
                    // session_start();
                    // if (isset($_POST['contactus'])) {
                    //     if ( empty(($_POST['fname'])) || empty(($_POST['lname'])) || empty(($_POST['lname'])) || empty(($_POST['email'])) || empty(($_POST['subject'])) || empty(($_POST['message'])) ) {
                    //         echo "All fields are required";
                        // } else {
                    //       # code...
                            // $db = mysqli_connect('localhost', 'root', '', 'contact');
                            // $conn = mysqli_connect('localhost', 'root', '', 'contact');
                            // $conn = new mysqli('localhost', 'root', '')
                    
                            // $conn->select_db('contact')
                                            
                    //       $fname = mysqli_real_escape_string($db, $_POST['fname']);
                    //       $lname = mysqli_real_escape_string($db, $_POST['lname']);
                    //       $email = mysqli_real_escape_string($db, $_POST['email']);
                    //       $subject = mysqli_real_escape_string($db, $_POST['subject']);
                    //       $message = mysqli_real_escape_string($db, $_POST['message']);

                            
                    //       $query = "INSERT INTO responses (fname, fname, email, subject, message) 
                    //       VALUES('$fname', '$lname', '$email', '$subject', '$message') ";
                    //       mysqli_query($db, $query);
                    //       $_SESSION['fname'] = $fname;
                    //       $_SESSION['success'] = "Thanks for contacting us";
                            

                        //   $fname = $_POST['fname']
                        //   $lname = $_POST['lname']
                        //   $email = $_POST['email']
                        //   $subject = $_POST['subject']
                        //   $message = $_POST['message']
                        //   $conn->query("INSERT INTO responses (fname, lname, email, subject, message ) values ('$fname', '$lname', '$email', '$subject', '$message') ");
                        //   echo "Thanks for contacting us";
                        // }


                    // } -->

                    

                    <div class="row form-group">
                        <div class="col-md-6 mb-3 mb-md-0">
                        <label class="text-black" for="fname" name="fname" >First Name</label>
                        <input type="text" id="fname" class="form-control">
                        </div>
                        <div class="col-md-6">
                        <label class="text-black" for="lname" name="lname">Last Name</label>
                        <input type="text" id="lname" class="form-control">
                        </div>
                    </div>

                    <div class="row form-group">
                        
                        <div class="col-md-12">
                        <label class="text-black" for="email" name="email">Email</label> 
                        <input type="email" id="email" class="form-control">
                        </div>
                    </div>

                    <div class="row form-group">
                        
                        <div class="col-md-12">
                        <label class="text-black" for="subject" name="subject">Subject</label> 
                        <input type="subject" id="subject" class="form-control">
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                        <label class="text-black" for="message" name="message">Message</label> 
                        <textarea name="message" id="message" cols="30" rows="7" class="form-control" placeholder="Write your notes or questions here..."></textarea>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col-md-12">
                        <input type="submit" value="Send Message" name= "contactus" class="btn btn-primary btn-md text-white">
                        </div>
                    </div>

        
                    </form>
                </div>
                <div class="col-md-5">
                    
                    <div class="p-4 mb-3 bg-white">
                    <p class="mb-0 font-weight-bold">Address</p>
                    <p class="mb-4">203 Kigali, Kacyru, Rwanda</p>

                    <p class="mb-0 font-weight-bold">Phone</p>
                    <p class="mb-4"><a href="#">+250789286589</a></p>

                    <p class="mb-0 font-weight-bold">Email Address</p>
                    <p class="mb-0"><a href="#">n.ngwa@alustudent.com</a></p>

                    </div>
                    
                </div>
                </div>
            </div>
        </section>
    </body>
</html>